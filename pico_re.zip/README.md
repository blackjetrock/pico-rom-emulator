# pico-rom-emulator
ROM Emulator using Pico
